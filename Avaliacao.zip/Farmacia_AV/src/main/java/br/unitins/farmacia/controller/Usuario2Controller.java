package br.unitins.farmacia.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

import br.unitins.farmacia.application.Util;
import br.unitins.farmacia.dao.Usuario2DAO;
import br.unitins.farmacia.model.Usuario2;

@Named
@ApplicationScoped
public class Usuario2Controller implements Serializable {

	private static final long serialVersionUID = 1258970559285652391L;
	private Usuario2 usuario2;
	private List<Usuario2> listaUsuario2;
	
	public void incluir() {
		Usuario2DAO dao = new Usuario2DAO();
		// gerando o hash da senha
		String senha = getUsuario2().getLogin() + getUsuario2().getSenha();
		senha = Util.hash(senha);
		getUsuario2().setSenha(senha);
		
		if (!dao.insert(getUsuario2())) {
			Util.addMessageInfo("Erro ao tentar incluir o usuário.");
			return;
		}
		limpar();
		setListaUsuario2(null);
		Util.addMessageInfo("Inclusão realizada com sucesso.");
	}

	public void alterar() {
		Usuario2DAO dao = new Usuario2DAO();
		
		// gerando o hash da senha
		String senha = getUsuario2().getLogin() + getUsuario2().getSenha();
		senha = Util.hash(senha);
		getUsuario2().setSenha(senha);
		
		if (!dao.update(getUsuario2())) {
			Util.addMessageInfo("Erro ao tentar alterar o usuário.");
			return;
		}
		limpar();
		setListaUsuario2(null);
		Util.addMessageInfo("Alteração realizada com sucesso.");
	}
	
	public void novo() {
		Util.redirect("usuario.xhtml");
	}
	
	public void novo2() {
		Util.redirect("usuario3.xhtml");
	}

	public void excluir() {
		excluir(getUsuario2().getId());
		limpar();
	}

	public void excluir(int id) {
		Usuario2DAO dao = new Usuario2DAO();
		if (!dao.delete(id)) {
			Util.addMessageInfo("Erro ao tentar excluir o usuário.");
			return;
		}
		setListaUsuario2(null);
		Util.addMessageInfo("Exclusão realizada com sucesso.");
	}

	public void editar(int id) {
		Usuario2DAO dao = new Usuario2DAO();
		setUsuario2(dao.getById(id));
		Util.redirect("usuario3.xhtml");

	}

	public void limpar() {
		usuario2 = null;
	}
	

	public Usuario2 getUsuario2() {
		if (usuario2 == null) {
			usuario2 = new Usuario2();
		}
		return usuario2;
	}

	public void setUsuario2(Usuario2 usuario2) {
		this.usuario2 = usuario2;
	}

	public List<Usuario2> getListaUsuario2() {
		if (listaUsuario2 == null) {
			Usuario2DAO dao = new Usuario2DAO();
			listaUsuario2 = dao.getAll();
			if (listaUsuario2 == null) 
				listaUsuario2 = new ArrayList<Usuario2>();
		}
		return listaUsuario2;
	}

	public void setListaUsuario2(List<Usuario2> listaUsuario2) {
		this.listaUsuario2 = listaUsuario2;
	}

}
