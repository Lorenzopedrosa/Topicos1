package br.unitins.farmacia.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import br.unitins.farmacia.model.ItemVenda;
import br.unitins.farmacia.model.Usuario2;
import br.unitins.farmacia.model.Venda;
import br.unitins.farmacia.dao.DAO;
import br.unitins.farmacia.dao.RemedioDAO;

public class ItemVendaDAO implements DAO<ItemVenda> {

	@Override
	public boolean insert(ItemVenda obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(ItemVenda obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<ItemVenda> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public ItemVenda findItemVendaByIdVenda(Integer idVenda, Integer idRemedio) {
		Connection conn = DAO.getConnection();
		if (conn == null) {
			return null;
		}
		ItemVenda item = new ItemVenda();
		
		String sql = "SELECT r.nome, iv.quantidade, iv.valor FROM remedio r, itemvenda iv WHERE r.id = ? AND iv.id_venda = ?";
		ResultSet rs = null;
		PreparedStatement stat = null;
		
		try {
			stat = conn.prepareStatement(sql);
			stat.setInt(1, idRemedio);
			stat.setInt(2, idVenda);
			rs = stat.executeQuery();
			
			while(rs.next()) {
				item.setNome(rs.getString("nome"));
				item.setValor(rs.getDouble("valor"));
				item.setQuantidade(rs.getInt("quantidade"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return item;
	}

	

}
