package br.unitins.farmacia.model;

import java.time.LocalDateTime;
import java.util.List;

public class Venda {

	private Integer id;
	private LocalDateTime dataVenda;
	private List<ItemVenda> listaItemVenda;
	private Double totalVenda;
	private Usuario2 usuario2;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getDataVenda() {
		return dataVenda;
	}

	public void setDataVenda(LocalDateTime dataVenda) {
		this.dataVenda = dataVenda;
	}

	public List<ItemVenda> getListaItemVenda() {
		return listaItemVenda;
	}

	public void setListaItemVenda(List<ItemVenda> listaItemVenda) {
		this.listaItemVenda = listaItemVenda;
	}

	public Usuario2 getUsuario2() {
		return usuario2;
	}

	public void setUsuario2(Usuario2 usuario2) {
		this.usuario2 = usuario2;
	}

	public Double getTotalVenda() {
		return totalVenda;
	}

	public void setTotalVenda(Double totalVenda) {
		this.totalVenda = totalVenda;
	}

}
