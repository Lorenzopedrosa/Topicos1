package br.unitins.farmacia.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

import br.unitins.farmacia.application.Session;
import br.unitins.farmacia.application.Util;
import br.unitins.farmacia.dao.VendaDAO;
import br.unitins.farmacia.model.Usuario;
import br.unitins.farmacia.model.Usuario2;
import br.unitins.farmacia.model.Venda;

@Named
@ViewScoped
public class HistoricoController implements Serializable {
	
	private static final long serialVersionUID = 7781080328315608995L;
	private List<Venda> listaVenda;
	
	public HistoricoController() {
		
	}
	
	public List<Venda> getListaVenda() {
		Usuario2 usuarioLogado1 = (Usuario2) Session.getInstance().get("usuarioLogado1");
		if (usuarioLogado1 == null) {
			listaVenda = new ArrayList<Venda>();
		} else {
			if (listaVenda == null) {
				VendaDAO dao = new VendaDAO();
				listaVenda = dao.getByUsuario2(usuarioLogado1);
				if (listaVenda == null)
					listaVenda = new ArrayList<Venda>();
			}
		}
		return listaVenda;
	}
	
	public void setListaVenda(List<Venda> listaVenda) {
		this.listaVenda = listaVenda;
	}
	
	public void detalhes(Venda venda) {
		Flash flash = FacesContext.getCurrentInstance().getExternalContext().getFlash();
		flash.put("vendaFlash", venda);
		Util.redirect("detalhevenda.xhtml");
		
	}
	
	
}
