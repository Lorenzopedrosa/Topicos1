package br.unitins.farmacia.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Named;

import br.unitins.farmacia.application.Session;
import br.unitins.farmacia.application.Util;
import br.unitins.farmacia.model.Usuario;
import br.unitins.farmacia.model.Usuario2;

@Named
@ViewScoped
public class TemplateController implements Serializable {

	private static final long serialVersionUID = 7581629149459236215L;

	private Usuario usuarioLogado;
	private Usuario2 usuarioLogado1;
	
	public Usuario getUsuarioLogado() {
		if (usuarioLogado == null) 
			usuarioLogado = (Usuario) Session.getInstance().get("usuarioLogado");
		return usuarioLogado;
	}
	
	public void encerrarSessao() {
		Session.getInstance().invalidateSession();
		Util.redirect("login2.xhtml");
	}

	public Usuario2 getUsuarioLogado1() {
		if (usuarioLogado1 == null) 
			usuarioLogado1 = (Usuario2) Session.getInstance().get("usuarioLogado1");
		return usuarioLogado1;
		}

	public void encerrarSessao1() {
		Session.getInstance().invalidateSession();
		Util.redirect("login3.xhtml");
	}
	
}
