package br.unitins.farmacia.controller;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import br.unitins.farmacia.application.Session;
import br.unitins.farmacia.application.Util;
import br.unitins.farmacia.dao.Usuario2DAO;
import br.unitins.farmacia.model.Usuario2;

@Named
@RequestScoped
public class Login2Controller {
	private Usuario2 usuario;
	
	public void entrar() {
		String hash = Util.hash(getUsuario2());
		Usuario2DAO dao = new Usuario2DAO();
		Usuario2 usuario = dao.verificarLogin(getUsuario2().getLogin(), hash);
		if (usuario == null) {
			Util.addMessageError("Login ou Senha est�o errados.");
			return;
		}
		// colocando o objeto na session
		Session.getInstance().set("usuarioLogado1", usuario);
		
// 		outra forma de colocar o objeto na session
//		FacesContext.getCurrentInstance().getExternalContext().
//		getSessionMap().put("usuarioLogado", usuario);
		
		Util.redirect("template3.xhtml");
	}
	
	public void limpar() {
		usuario = null;
	}

	public Usuario2 getUsuario2() {
		if (usuario == null)
			usuario = new Usuario2();
		return usuario;
	}

	public void setUsuario2(Usuario2 usuario) {
		this.usuario = usuario;
	}
	
}
